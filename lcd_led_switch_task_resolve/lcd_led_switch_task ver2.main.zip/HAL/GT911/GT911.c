#include "GT911.h"

Touch_data_t touchData;
static volatile uint8_t GT911_interruptFlag = 0;

void GT911_reset(void)
{
    GT911_RST_CLR();
    Delay_Ms(10);
    GT911_RST_SET();
    Delay_Ms(10);
}

//set iic address 0xBA/0xBB
void GT911_set_iic_address(void)
{

    GT911_INT_CLR();
    GT911_RST_CLR();
    Delay_Ms(20);
    GT911_RST_SET();
    Delay_Ms(50);
    GT911_INT_IN();
}

uint8_t GT911_read_register(uint16_t reg, uint8_t* buf, uint8_t length)
{
    uint8_t error = 0;
    
    printf("[I2C] Starting I2C read transaction...\r\n");
    
    // 发送START条件
    printf("[I2C] Sending START condition...\r\n");
    GT911_iic_start();
    
    // 检查SCL线状态，如果为低则START条件失败
    GT911_SCL_IN();
    Delay_Us(DELAY_TIME_US);
    if(GT911_SCL_READ() == 0) {
        printf("[I2C] ERROR: START condition failed - SCL is still LOW\r\n");
        printf("[I2C] I2C bus is stuck. Check pull-up resistors and connections.\r\n");
        return 1;
    }
    
    // 发送设备写地址
    printf("[I2C] Sending write address: 0x%02X...\r\n", GT911_IIC_WRITE_ADDRESS);
    GT911_iic_send_byte(GT911_IIC_WRITE_ADDRESS);
    error = GT911_iic_wait_ack();
    if(error) {
        printf("[I2C] ERROR: I2C write address NACK (no ACK from device)\r\n");
        GT911_iic_stop();
        return 1;
    }
    printf("[I2C] Write address ACK received.\r\n");
    
    // 发送寄存器高字节
    printf("[I2C] Sending register high byte: 0x%02X...\r\n", (reg>>8) & 0xFF);
    GT911_iic_send_byte(reg>>8);
    error = GT911_iic_wait_ack();
    if(error) {
        printf("[I2C] ERROR: I2C register high byte NACK\r\n");
        GT911_iic_stop();
        return 1;
    }
    printf("[I2C] Register high byte ACK received.\r\n");
    
    // 发送寄存器低字节
    printf("[I2C] Sending register low byte: 0x%02X...\r\n", reg & 0xFF);
    GT911_iic_send_byte(reg&0xff);
    error = GT911_iic_wait_ack();
    if(error) {
        printf("[I2C] ERROR: I2C register low byte NACK\r\n");
        GT911_iic_stop();
        return 1;
    }
    printf("[I2C] Register low byte ACK received.\r\n");
    
    // 发送重复START条件
    printf("[I2C] Sending repeated START condition...\r\n");
    GT911_iic_start();
    
    // 发送设备读地址
    printf("[I2C] Sending read address: 0x%02X...\r\n", GT911_IIC_READ_ADDRESS);
    GT911_iic_send_byte(GT911_IIC_READ_ADDRESS);
    error = GT911_iic_wait_ack();
    if(error) {
        printf("[I2C] ERROR: I2C read address NACK\r\n");
        GT911_iic_stop();
        return 1;
    }
    printf("[I2C] Read address ACK received.\r\n");

    // 读取数据
    printf("[I2C] Reading %d bytes of data...\r\n", length);
    for(uint8_t i=0; i<length; i++)
    {
        buf[i] = GT911_iic_read_byte(i==(length-1)?0:1);
        printf("[I2C] Byte %d: 0x%02X\r\n", i, buf[i]);
    }
    
    // 发送STOP条件
    printf("[I2C] Sending STOP condition...\r\n");
    GT911_iic_stop();
    
    printf("[I2C] I2C read transaction completed successfully.\r\n");
    return 0;
}

uint8_t GT911_write_register(uint16_t reg, uint8_t* buf, uint8_t length)
{
    uint8_t returnVlaue = 0;
    GT911_iic_start();
    GT911_iic_send_byte(GT911_IIC_WRITE_ADDRESS);
    GT911_iic_wait_ack();
    GT911_iic_send_byte(reg>>8);
    GT911_iic_wait_ack();
    GT911_iic_send_byte(reg&0xff);
    GT911_iic_wait_ack();
    for(uint8_t i=0; i<length; i++)
    {
        GT911_iic_send_byte(buf[i]);
        returnVlaue = GT911_iic_wait_ack();
        if(returnVlaue) break;
    }
    GT911_iic_stop();

    return returnVlaue;
}


void GT911_interrupt_init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure = {0};
    EXTI_InitTypeDef EXTI_InitStructure = {0};

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO | RCC_APB2Periph_GPIOD, ENABLE);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOD, &GPIO_InitStructure);

    /* GPIOD ----> EXTI_Line2 */
    GPIO_EXTILineConfig(GPIO_PortSourceGPIOD, GPIO_PinSource2);
    EXTI_InitStructure.EXTI_Line = EXTI_Line2;
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);

    // 设置中断优先级为中等优先级（避免与其他中断冲突）
    NVIC_SetPriority(EXTI2_IRQn,0x02);
    NVIC_EnableIRQ(EXTI2_IRQn);
}



void GT911_init(void)
{
    uint8_t touchID[6]={0};

    printf("[GT911] Initializing I2C GPIO...\r\n");
    GT911_iic_gpio_init();
    printf("[GT911] I2C GPIO initialized.\r\n");
    
    printf("[GT911] Resetting GT911...\r\n");
    GT911_reset();
    printf("[GT911] GT911 reset completed.\r\n");
    
    printf("[GT911] Setting I2C address...\r\n");
    GT911_set_iic_address();//0xBA/0xBB
    printf("[GT911] I2C address set.\r\n");
    
    printf("[GT911] Reading touch IC ID...\r\n");
    uint8_t read_result = GT911_read_register(GT911_ID_ADDRESS,touchID,4);
    if(read_result == 0)
    {
        printf("[GT911] Touch IC ID = %s\r\n",touchID);
        
        // 检查是否读取到有效的ID
        if(touchID[0] == 0 && touchID[1] == 0 && touchID[2] == 0 && touchID[3] == 0)
        {
            printf("[GT911] WARNING: Touch IC ID is all zeros! Check I2C connection.\r\n");
        }
        else
        {
            printf("[GT911] Touch IC ID read successfully.\r\n");
        }
    }
    else
    {
        printf("[GT911] ERROR: Failed to read touch IC ID! I2C communication error.\r\n");
        // 继续初始化，但触摸功能可能不可用
    }

//    GT911_read_register(GT911_CFGS_REG, touchID, 6);
//
//    for(uint8_t i=0;i<6;i++)
//    {
//        printf("touchID[%d] = 0x%x\r\n",i,touchID[i]);
//    }

    printf("[GT911] Initializing interrupt...\r\n");
    GT911_interrupt_init();
    printf("[GT911] Interrupt initialized.\r\n");
    
    printf("[GT911] Initialization completed.\r\n");

}

void GT911_touch_scanf(Touch_data_t* touchData)
{


    if(GT911_interruptFlag)
    {
        GT911_interruptFlag = 0;
        uint8_t temp = 0;
        uint8_t read_result = GT911_read_register(GT911_BUFFER_STATUS,&temp,1);
        if(read_result == 0)
        {
            touchData->TouchState = temp&0x80;
            touchData->TouchNumber = temp&0x0f;
            if(touchData->TouchNumber > GT911_TOUCH_MAX_NUM)
            {
                touchData->TouchState = 0;
                temp = 0;
                GT911_write_register(GT911_BUFFER_STATUS,&temp,1);
            }

            if(touchData->TouchState == 0x80)
            {
                temp = 0;
                GT911_write_register(GT911_BUFFER_STATUS,&temp,1);

                for(uint8_t i=0; i<touchData->TouchNumber; i++)
                {
                    if(GT911_read_register((GT911_BUFFER_START + i*8 + 0), &temp, 1) == 0) //��������x����ĵ�8λ
                        touchData->Touch_xy[i].PointX  = temp;
                    if(GT911_read_register((GT911_BUFFER_START + i*8 + 1), &temp, 1) == 0) //��������x����ĸ�8λ
                        touchData->Touch_xy[i].PointX |= (temp<<8);

                    if(GT911_read_register((GT911_BUFFER_START + i*8 + 2), &temp, 1) == 0) //��������y����ĵ�8λ
                        touchData->Touch_xy[i].PointY  = temp;
                    if(GT911_read_register((GT911_BUFFER_START + i*8 + 3), &temp, 1) == 0) //��������y����ĸ�8λ
                        touchData->Touch_xy[i].PointY |= (temp<<8);

                    if(GT911_read_register((GT911_BUFFER_START + i*8 + 4), &temp, 1) == 0) //����������С���ݵĵ�8λ
                        touchData->Touch_xy[i].PointS  = temp;
                    if(GT911_read_register((GT911_BUFFER_START + i*8 + 5), &temp, 1) == 0) //����������С���ݵĸ�8λ
                        touchData->Touch_xy[i].PointS |= (temp<<8);
                }
            }
        }
    }


}


void EXTI2_IRQHandler(void) __attribute__((interrupt("WCH-Interrupt-fast")));
void EXTI2_IRQHandler(void)
{
    if(EXTI_GetITStatus(EXTI_Line2)!=RESET)
    {
        GT911_interruptFlag = 1;
        EXTI_ClearITPendingBit(EXTI_Line2);     /* Clear Flag */
    }
}

