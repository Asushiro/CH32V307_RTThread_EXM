#include "GT911_IIC.h"

#define DELAY_TIME_US 10

void GT911_iic_gpio_init(void)
{
    // 启用GPIO和AFIO时钟
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO | RCC_APB2Periph_GPIOE | RCC_APB2Periph_GPIOD | RCC_APB2Periph_GPIOB, ENABLE);
    
    // 初始化SCL为输出高电平
    GT911_SCL_OUT();
    GT911_SCL_SET();
    
    // 初始化SDA为输出高电平，然后释放总线（设置为输入）
    GT911_SDA_OUT();
    GT911_SDA_SET();
    // 释放SDA总线，设置为输入模式（高阻态）
    GT911_SDA_IN();
    
    GT911_RST_OUT();
    GT911_INT_OUT();

    GT911_INT_SET();
    GT911_RST_SET();
    
    // 添加延时确保GPIO稳定
    Delay_Ms(10);
    
    printf("[I2C] GPIO initialized: SCL=PB10, SDA=PB11, INT=PD2, RST=PE0\r\n");
    printf("[I2C] SCL and SDA should have external pull-up resistors (4.7k-10k)\r\n");
}

void GT911_iic_start(void)
{
    // 检查SCL线状态
    GT911_SCL_IN();
    Delay_Us(DELAY_TIME_US);
    
    uint32_t scl_state = GT911_SCL_READ();
    printf("[I2C] GT911_iic_start: Checking SCL line... state=%s\r\n", scl_state ? "HIGH" : "LOW");
    
    // 如果SCL被拉低，I2C总线被占用，无法发送START条件
    if(scl_state == 0) {
        printf("[I2C] ERROR: Cannot send START condition - SCL is LOW (bus busy or missing pull-up)\r\n");
        printf("[I2C] Hardware issue: Check 4.7k-10k pull-up resistors on SCL(PB10) to 3.3V\r\n");
        // 不执行START条件，直接返回
        return;
    }
    
    printf("[I2C] GT911_iic_start: SCL is HIGH, proceeding with START condition\r\n");
    
    // 正常的START条件
    GT911_SDA_OUT();
    GT911_SCL_OUT();
    GT911_SCL_SET();
    GT911_SDA_SET();
    Delay_Us(DELAY_TIME_US);
    GT911_SDA_CLR();
    Delay_Us(DELAY_TIME_US);
    GT911_SCL_CLR();
    Delay_Us(DELAY_TIME_US);
    
    printf("[I2C] GT911_iic_start: START condition completed\r\n");
}

void GT911_iic_stop(void)
{
    GT911_SDA_OUT();
    GT911_SCL_CLR();
    GT911_SDA_CLR();
    Delay_Us(DELAY_TIME_US);
    GT911_SCL_SET();
    Delay_Us(DELAY_TIME_US);
    GT911_SDA_SET();
}

void GT911_iic_ack(void)
{
    GT911_SCL_CLR();
    GT911_SDA_OUT();
    GT911_SDA_CLR();
    Delay_Us(DELAY_TIME_US);
    GT911_SCL_SET();
    Delay_Us(DELAY_TIME_US);
    GT911_SCL_CLR();

}

void GT911_iic_nak(void)
{
    GT911_SCL_CLR();
    GT911_SDA_OUT();
    GT911_SDA_SET();
    Delay_Us(DELAY_TIME_US);
    GT911_SCL_SET();
    Delay_Us(DELAY_TIME_US);
    GT911_SCL_CLR();
}

uint8_t GT911_iic_wait_ack(void)
{
    uint16_t waitTime = 0;  // 增加超时计数范围
    GT911_SDA_IN();
    // GT911_SDA_SET();  // 这行可能不需要，SDA已经是输入模式
    
    Delay_Us(DELAY_TIME_US);
    GT911_SCL_SET();
    Delay_Us(DELAY_TIME_US);
    
    // 等待SDA线变低（ACK信号）
    while(GT911_SDA_READ())
    {
        waitTime++;
        Delay_Us(10);  // 添加延时，避免过快计数
        
        if(waitTime > 1000)  // 增加超时时间
        {
            printf("[I2C] ERROR: Timeout waiting for ACK (SDA stuck high)\r\n");
            GT911_iic_stop();
            return 1;
        }
    }
    
    GT911_SCL_CLR();
    Delay_Us(DELAY_TIME_US);
    return 0;
}

void GT911_iic_send_byte(uint8_t data)
{
    GT911_SCL_CLR();
    GT911_SDA_OUT();

    for(uint8_t i=0; i<8; i++)
    {
        if((data&0x80)>>7)
        {
            GT911_SDA_SET();
        }
        else
        {
            GT911_SDA_CLR();
        }
        data<<=1;
        Delay_Us(5);
        GT911_SCL_SET();
        Delay_Us(DELAY_TIME_US);
        GT911_SCL_CLR();
        Delay_Us(DELAY_TIME_US);
    }
}

/*
 * ack = 1, send ack
 * ack = 0, send nak
 *
 * */
uint8_t GT911_iic_read_byte(uint8_t ack)
{
   uint8_t receiveData = 0;
   GT911_SDA_IN();
   for(uint8_t i=0; i<8; i++)
   {
       GT911_SCL_CLR();
       Delay_Us(DELAY_TIME_US);
       GT911_SCL_SET();
       Delay_Us(DELAY_TIME_US);
       receiveData<<=1;
       if(GT911_SDA_READ())receiveData++;

   }
   if(ack)
   {
       GT911_iic_ack();
   }
   else
   {
       GT911_iic_nak();
   }

   return receiveData;
}

