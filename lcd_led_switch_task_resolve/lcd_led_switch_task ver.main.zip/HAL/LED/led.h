/********************************** (C) COPYRIGHT *******************************
 * File Name          : led.h
 * Author             : WCH
 * Version            : V1.0
 * Date               : 2023/10/9
 * Description        :
 * Copyright (c) 2021 Nanjing Qinheng Microelectronics Co., Ltd.
 * SPDX-License-Identifier: Apache-2.0
 *******************************************************************************/

/******************************************************************************/
#ifndef __LED_H
#define __LED_H

#ifdef __cplusplus
extern "C" {
#endif

#include "ch32v30x_conf.h"

/*********************************************************************
 * CONSTANTS
 */
#define RED_ON()            (GPIO_SetBits(GPIOB, GPIO_Pin_3))   //�����
#define RED_OFF()           (GPIO_ResetBits(GPIOB, GPIO_Pin_3))     //�غ��
#define GREEN_ON()          (GPIO_SetBits(GPIOB, GPIO_Pin_4))   //���̵�
#define GREEN_OFF()         (GPIO_ResetBits(GPIOB, GPIO_Pin_4))     //���̵�
#define BLUE_ON()           (GPIO_SetBits(GPIOB, GPIO_Pin_5))   //������
#define BLUE_OFF()          (GPIO_ResetBits(GPIOB, GPIO_Pin_5))     //������

#define LED_CONTROL_TIM_CLOCK           100000                                          //LED���ƶ�ʱ��2ʱ��100KHz
#define LED_CONTROL_TIM_PRESCALER       (SystemCoreClock / LED_CONTROL_TIM_CLOCK - 1)   //��ʱ��2��ʱ�ӷ�Ƶϵ��,Ƶ��Ϊ100KHz,����Ϊ10us
#define LED_CONTROL_TIM_PERIOD_1MS      (LED_CONTROL_TIM_CLOCK / 100000 * 100 - 1)      //LED���Ƶ�PWM����Ϊ100*10us=1ms

/*********************************************************************
 * TYPEDEFS
 */
typedef enum
{
    kBlack = 0, //��ɫ
    kWhite,     //��ɫ
    kRed,       //��ɫ
    kGreen,     //��ɫ
    kBlue,      //��ɫ
    kYellow,    //��ɫ
    kMagenta,   //Ʒ��/����ɫ
    kCyan       //��ɫ
}led_color_t;

typedef enum
{
    kALL_LED = 0,   //���е�
    kRED_LED,       //�� PB3
    kGREEN_LED,     //�� PB4
    kBLUE_LED       //�� PB5
}led_num_t;

/*********************************************************************
 * GLOBAL VARIABLES
 */
extern uint8_t led_level;       //��ǰLED������,�ٷֱ�

/**
 * @brief   GPIO����LED��ʼ��
 */
void led_init(void);

/**
 * @brief   �ı�LED��ʾ����ɫ
 */
void led_color_change(led_color_t color);

/**
 * @brief   PWM����LED��ʼ��
 */
void led_pwm_init(u16 arr, u16 psc, u16 ccp);

/**
 * @brief   LED�����ȿ���
 */
void led_pwm_control(led_num_t led_num, uint16_t period, uint8_t per);

/*********************************************************************
*********************************************************************/

#ifdef __cplusplus
}
#endif

#endif
